#v0.1.0

* First version

#v0.2.0

* Add branching capabilities